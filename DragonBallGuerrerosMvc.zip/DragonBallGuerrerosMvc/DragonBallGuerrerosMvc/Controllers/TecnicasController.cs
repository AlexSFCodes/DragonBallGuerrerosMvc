using System.Linq;
using System.Net;
using System.Web.Mvc;
using DragonBallGuerrerosMvc.Models;

namespace DragonBallGuerrerosMvc.Controllers
{
    public class TecnicasController : Controller
    {
        private readonly DragonBallDbContext db = new DragonBallDbContext();

        // GET: Tecnicas
        public ActionResult Index()
        {
            return View(db.Tecnicas.ToList());
        }

        // GET: Tecnicas/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Tecnica tecnica = db.Tecnicas.Find(id);
            if (tecnica == null)
            {
                return HttpNotFound();
            }
            return View(tecnica);
        }

        // GET: Tecnicas/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Tecnicas/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Nombre")] Tecnica tecnica)
        {
            if (ModelState.IsValid)
            {
                db.Tecnicas.Add(tecnica);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tecnica);
        }

        // GET: Tecnicas/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Tecnica tecnica = db.Tecnicas.Find(id);
            if (tecnica == null)
            {
                return HttpNotFound();
            }
            return View(tecnica);
        }

        // POST: Tecnicas/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "TecnicaId,Nombre")] Tecnica tecnica)
        {
            Tecnica existente = db.Tecnicas.Find(tecnica.TecnicaId);
            if (existente == null)
            {
                return HttpNotFound();
            }

            if (ModelState.IsValid)
            {
                existente.Nombre = tecnica.Nombre;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tecnica);
        }

        // GET: Tecnicas/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Tecnica tecnica = db.Tecnicas.Find(id);
            if (tecnica == null)
            {
                return HttpNotFound();
            }
            return View(tecnica);
        }

        // POST: Tecnicas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Tecnica tecnica = db.Tecnicas.Find(id);
            if (tecnica == null)
            {
                return HttpNotFound();
            }

            db.Tecnicas.Remove(tecnica);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
